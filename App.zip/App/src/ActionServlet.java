

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ActionServlet
 */
@WebServlet("/ActionServlet")
public class ActionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*if(request.getParameterValues("sno")!=null){
			String[] snos = request.getParameterValues("sno");
			System.out.println(snos);
		}*/
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean isInert = false;
		ExcelBook book = new ExcelBook();
		String sheetName = null;
		String viewType	 = null; 
		try{
			if(request.getParameter("sheetName")!=null &&
					request.getParameterValues("sno")!=null && 
					(request.getParameterValues("name")!=null) &&
						(request.getParameterValues("inc")!=null)){
				String[] sno = request.getParameterValues("sno");
				String[] name = request.getParameterValues("name");
				String[] inc = request.getParameterValues("inc");
				sheetName = request.getParameter("sheetName");
				viewType  = request.getParameter("viewType"); 
				List<BookSheet> list = null;
				BookSheet sheet = null;
				if(sno.length>0){
					list = new ArrayList<BookSheet>();
					for(int i=0;i<sno.length;i++){
						sheet = new BookSheet();
						sheet.setSno((String)sno[i]);
						sheet.setName((String)name[i]);
						sheet.setInc((String)inc[i]);
						list.add(sheet);
					}
					if(list!=null && list.size()>0){
						isInert = book.insertNewRow(list,sheetName)?true:false;
					}
				}
			}	
			if(isInert && viewType!=null){
				response.sendRedirect("ViewSheet?viewType="+viewType+"&sheet="+sheetName);
			}else{
				response.getWriter().append("File Not Writted got Some Error: @ ").append(request.getContextPath());
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

}
