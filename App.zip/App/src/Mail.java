
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class Mail {
	
	public String sendMail(String msg,String sheetName){
		
		    String to = "mohanstar13@gmail.com";
		    String from = "mohanengg13@gmail.com";
		    String pass = "8870548472";
		    String fromName = "Mohan";
		    String subject = "TEST Messge For EOD";
		    String ret	= "normal";
		    
		    Properties props = new Properties();
		    
		    props.put("mail.smtp.user", from);
		    props.put("mail.smtp.host", "smtp.gmail.com");
		    props.put("mail.smtp.port", "465");
		    props.put("mail.smtp.starttls.enable", "true");
		    props.put("mail.smtp.debug", "true");
		    props.put("mail.smtp.auth", "true");
		    props.put("mail.smtp.socketFactory.port", "465");
		    props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		    props.put("mail.smtp.socketFactory.fallback", "false");
		    
		    Session session = Session.getInstance(props, 
		      new Authenticator()
		      {
		        protected PasswordAuthentication getPasswordAuthentication()
		        {
		          return new PasswordAuthentication(from, pass);
		        }
		      });
		    try
		    {
		      session.setDebug(true);
		      
		      Message message = new MimeMessage(session);
		      
		      message.setFrom(new InternetAddress(from, fromName));
		      
		      message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
		      
		      message.setSubject(subject + " | " + from);
		      
		      Multipart multiPart = new MimeMultipart("alternative");
		      
		      MimeBodyPart htmlPart = new MimeBodyPart();
		      SelectTodatDate Eod=new SelectTodatDate();
		      StringBuffer strBuf	= new StringBuffer();
		      List<BookSheet> datas= Eod.getAllRowValues(sheetName,"07-01-2017");
		      BookSheet sheet		= null;
		      Iterator<BookSheet> itr = datas.iterator();
				strBuf.append("<table id='customFields'><tr><td>S.no</td><td>Name</td><td>inc</td></tr>");
				while(itr.hasNext()){
					sheet = itr.next();
					if(sheet!=null){
						strBuf.append("<tr>");
						strBuf.append("<td>"+sheet.getSno()+"</td>");
						strBuf.append("<td>"+sheet.getName()+"</td>");
						strBuf.append("<td>"+sheet.getInc()+"</td>");
						strBuf.append("</tr>");
					}
				}
				strBuf.append("</table><br>");
		      
		      String html = "<span style='color:#61686b;font-size: 15px;'>" + fromName + " > Says : <b>" + msg + "</b></span>";
		      htmlPart.setContent(strBuf.toString(), "text/html; charset=utf-8");
		      System.out.println(strBuf.toString());
		      multiPart.addBodyPart(htmlPart);
		      message.setContent(multiPart);
		      
		      Transport transport = session.getTransport("smtps");
		      transport.connect("smtp.gmail.com", 465, from, pass);
		      transport.sendMessage(message, message.getAllRecipients());
		      transport.close();
		      
		      ret = "success"; 
		    }
		    catch (Exception ex){
		    	ex.printStackTrace();
		       System.out.println(ex.getMessage());
		       ret = "failure";
		    }
		    
	  return ret;
	}
	
}
