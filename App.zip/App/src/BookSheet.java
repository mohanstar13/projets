import java.io.Serializable;

public class BookSheet implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

private String sno;

private String name;

private String inc;

private String sheetName;

public String getSheetName() {
	return sheetName;
}

public void setSheetName(String sheetName) {
	this.sheetName = sheetName;
}

public String getSno() {
	return sno;
}

public void setSno(String sno) {
	this.sno = sno;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getInc() {
	return inc;
}

public void setInc(String inc) {
	this.inc = inc;
}

public String toString(){
	return "[" +sheetName+ " "+sno+" "+name+" "+inc+ "]";
}
}
