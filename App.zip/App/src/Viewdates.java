import java.util.Iterator;
import java.util.List;

public class Viewdates {
	
	public String dateSearch(String fromDate,String toDate,String sheetName){
		try{
		 StringBuffer strBuf	= new StringBuffer();
	      List<BookSheet> datas= SelectTodatDate.getFromtoDate(fromDate,toDate,sheetName);
	      BookSheet sheet		= null;
	      Iterator<BookSheet> itr = datas.iterator();
			strBuf.append("<table id='newAjaxTable'><thead><tr><td>S.no</td><td>Name</td><td>inc</td></tr></thead>");
			strBuf.append("<tbody>");
			while(itr.hasNext()){
				sheet = itr.next();
				if(sheet!=null){
					strBuf.append("<tr>");
					strBuf.append("<td>"+sheet.getSno()+"</td>");
					strBuf.append("<td>"+sheet.getName()+"</td>");
					strBuf.append("<td>"+sheet.getInc()+"</td>");
					strBuf.append("</tr>");
				}
			}
			strBuf.append("</tbody>");
			strBuf.append("<tfoot></tfoot>");
			strBuf.append("</table><br>");
			System.out.println(strBuf.toString());
			return strBuf.toString();
		}
		catch (Exception ex){
	    	ex.printStackTrace();
	       System.out.println(ex.getMessage());
	       return "failure";
	    }
		
	}
	

}
