import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class ExcelBook {

	public boolean insertNewRow(List<BookSheet> list,String sheetName){
		boolean inserted = false;
		XSSFWorkbook workbook 	= null;
		XSSFSheet sheet 		= null;
		BookSheet bookSheet		= null;
		FileOutputStream out    = null;
		FileInputStream fis		= null;
		try{
			fis	= new FileInputStream(new File("D:\\"+sheetName+".xlsx"));
			workbook = new XSSFWorkbook(fis);
			sheet = (workbook.getSheetAt(0)==null)? workbook.createSheet():workbook.getSheetAt(0);
			int sheetRownum = sheet.getLastRowNum()+1;
			Iterator<BookSheet> itr = list.iterator();
			while(itr.hasNext()){
				int cellIdx = 0;
				bookSheet = itr.next();
				Row row = sheet.createRow(sheetRownum++);
				row.createCell(cellIdx++).setCellValue((String)bookSheet.getSno());
				row.createCell(cellIdx++).setCellValue((String)bookSheet.getName());
				row.createCell(cellIdx++).setCellValue((String)bookSheet.getInc());				
			}
			out = new FileOutputStream(new File("D:\\"+sheetName+".xlsx"));
            workbook.write(out);
            workbook.close();
            out.close();
            fis.close();
            System.out.println("howtodoinjava_demo.xlsx written successfully on disk.");
			inserted = true;
		}catch(Exception ex){
			inserted = false;
			System.out.println("Error"+ex.getMessage());
			ex.printStackTrace();
		}
		return inserted;
	}
	
	public static XSSFWorkbook getOrCreateSheet(String sheetName){
		XSSFWorkbook workbook 	= null;
		FileInputStream fis		= null;
		try{
			if(sheetName!=null){
				File file 	= new File("d:\\"+sheetName+".xlsx");
				if(file.isFile() && file.canWrite()){
					fis			= new FileInputStream(file);
				}else{
					file.createNewFile();
					fis			= new FileInputStream(file);
				}
				workbook	= new XSSFWorkbook(fis);
				fis.close();
			}
		}catch(Exception ex){
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		return (workbook);
	}
	/*public boolean insertRowOnSheet(List<BookSheet> list,String sheetName){
		boolean inserted = false;
		try{		
			Iterator<BookSheet> itr = list.iterator();
			while(itr.hasNext()){
				XSSFSheet sheet = null;
				BookSheet bookSheet = null;
				XSSFWorkbook workbook = null;
				FileOutputStream out  = null;
					int cellIdx = 0;
					bookSheet = itr.next();
					workbook	= getOrCreateSheet(bookSheet.getName());
					if(workbook!=null){
						sheet = (workbook.getSheet(bookSheet.getName())==null)? workbook.createSheet(bookSheet.getName()):workbook.getSheet(bookSheet.getName());
						Row row = sheet.createRow(sheet.getLastRowNum()+2);
						row.createCell(cellIdx++).setCellValue((String)bookSheet.getSno());
						row.createCell(cellIdx++).setCellValue((String)bookSheet.getName());
						row.createCell(cellIdx++).setCellValue((String)bookSheet.getInc());
						out = new FileOutputStream(new File("D:\\"+bookSheet.getName()+".xlsx"));
			            workbook.write(out);
			            out.close();
			            workbook.close();
			            System.out.println("howtodoinjava_demo.xlsx written successfully on disk.");
					}
			}
			inserted = true;
		}catch(Exception ex){
			inserted = false;
			System.out.println("Error"+ex.getMessage());
			ex.printStackTrace();
		}
		return inserted;
	}*/
	public static List<BookSheet> getAllRowValues(String sheetName){
		List<BookSheet>	list 	= null;
		FileInputStream fis		= null;
		XSSFWorkbook book		= null;
		XSSFSheet sheet			= null;
		BookSheet bookSheet		= null;
		try{
			fis	= new FileInputStream(new File("D:\\"+sheetName+".xlsx"));
			book= new XSSFWorkbook(fis);
			sheet = book.getSheetAt(0);
			list = new ArrayList<BookSheet>();
			Iterator<Row> rowItr = sheet.iterator();
			while(rowItr.hasNext()){
				bookSheet 	= new BookSheet();
				int cellIdx = 0;
				Row row 	= rowItr.next();
				bookSheet.setSheetName(sheetName);
				if(row.getCell(0)!=null)
				bookSheet.setSno(getCellValue(row.getCell(0)));
				if(row.getCell(1)!=null)
				bookSheet.setName(getCellValue(row.getCell(1)));
				if(row.getCell(2)!=null)
				bookSheet.setInc(getCellValue(row.getCell(2)));
				list.add(bookSheet);
			}
		}catch(Exception ex){
			System.out.println("Error:getAllValues:"+ex.getMessage());
		}finally{
			try {
				fis.close();
				book.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public static StringBuffer getSheetValueAsJson(List<BookSheet> list){
		StringBuffer strBuf	= new StringBuffer();
		BookSheet sheet		= null;
		try{
			if(list!=null && list.size()>0){
				Iterator<BookSheet> itr = list.iterator();
				strBuf.append("'Book':['");
				int count = 0;
				while(itr.hasNext()){
					sheet = itr.next();
					if(sheet!=null){
						count+=1;
						if(count!=1){
							strBuf.append(",");	
						}
						strBuf.append("sheet"+(count)+"':{");
						strBuf.append("'"+sheet.getSno()+"',");
						strBuf.append("'"+sheet.getName()+"',");
						strBuf.append("'"+sheet.getInc()+"'");
						strBuf.append("}");
					}
				}
				strBuf.append("]");
			}
		}catch(Exception ex){
			System.out.println("Error"+ex.getMessage());
			ex.printStackTrace();
		}
		return strBuf;
	}
	
	public static StringBuffer getSheetValueAsHtml(List<BookSheet> list){
		StringBuffer strBuf	= new StringBuffer();
		BookSheet sheet		= null;
		try{
			if(list!=null && list.size()>0){
				Iterator<BookSheet> itr = list.iterator();
				strBuf.append("<div id='nedata'>Data Insert Successfully</div><br>");
				strBuf.append("<table id='newTable'><thead><tr><td>S.no</td><td>Name</td><td>inc</td></tr></thead>");
				strBuf.append("<tbody>");
				while(itr.hasNext()){
					sheet = itr.next();
					if(sheet!=null){
						strBuf.append("<tr>");
						strBuf.append("<td>"+sheet.getSno()+"</td>");
						strBuf.append("<td>"+sheet.getName()+"</td>");
						strBuf.append("<td>"+sheet.getInc()+"</td>");
						strBuf.append("</tr>");
					}
				}
				strBuf.append("</tbody><tfoot></tfoot>");
				strBuf.append("</table><br>");
				//strBuf.append("<a href='view.jsp'>View Information</a><br>");
				//strBuf.append("<a href='index.jsp'>Back Home</a><br><br>");
			}
		}catch(Exception ex){
			System.out.println("Error"+ex.getMessage());
			ex.printStackTrace();
		}
		return strBuf;
	}
	
	public static String getCellValue(Cell cell){
		try{
			if(cell!=null){
				switch (cell.getCellType()) {
	            case HSSFCell.CELL_TYPE_STRING:
	                return cell.getStringCellValue();
	            case HSSFCell.CELL_TYPE_NUMERIC:
	                return Double.toString(cell.getNumericCellValue());
	            case HSSFCell.CELL_TYPE_BOOLEAN:
	                return Boolean.toString(cell.getBooleanCellValue());
	            case HSSFCell.CELL_TYPE_FORMULA:
	                cell.getCellFormula();
	            }
					
			}
		}catch(Exception ex){
			System.out.println("Error:"+ex.getMessage());
			ex.printStackTrace();
		}
		return null;
	}
	
	public static boolean isValidSheet(String sheetName){
		boolean flag = false;
		try{
			File file 	= new File("D:\\"+sheetName+".xlsx");
			flag 		= file.isFile(); 
		}catch(Exception ex){
			System.out.println("Error:"+ex.getMessage());
			ex.printStackTrace();
		}
		return flag;
	}
	
	public static String getValuesAsJson(List<BookSheet> list){
		String json = "'object':'null'";
		try{
			ObjectMapper mapper = new ObjectMapper();
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			json = mapper.writeValueAsString(list); 
		}catch(Exception ex){
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		return json;
	}
	//public 
}