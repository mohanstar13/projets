import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SelectTodatDate {
	public static List<BookSheet> getAllRowValues(String sheetName,String date){
		List<BookSheet>	list 	= null;
		FileInputStream fis		= null;
		XSSFWorkbook book		= null;
		XSSFSheet sheet			= null;
		BookSheet bookSheet		= null;
		try{
			fis	= new FileInputStream(new File("D:\\"+sheetName+".xlsx"));
			book= new XSSFWorkbook(fis);
			sheet = book.getSheetAt(0);
			list = new ArrayList<BookSheet>();
			Iterator<Row> rowItr = sheet.iterator();
			while(rowItr.hasNext()){
				bookSheet 	= new BookSheet();
				int cellIdx = 0;
				Row row 	= rowItr.next();
				bookSheet.setSheetName(sheetName);
				 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			        Date date1 = sdf.parse("2017-01-07");
			        Date date2 = sdf.parse(getCellValue(row.getCell(1)));
				System.out.println(date1);
				System.out.println(date2);
				
				if(date1.compareTo(date2) == 0){
					if(row.getCell(0)!=null)
					bookSheet.setSno(getCellValue(row.getCell(0)));
					if(row.getCell(1)!=null)
					bookSheet.setName(getCellValue(row.getCell(1)));
					if(row.getCell(2)!=null)
					bookSheet.setInc(getCellValue(row.getCell(2)));
					list.add(bookSheet);
				}
				
			}
		}catch(Exception ex){
			System.out.println("Error:getAllValues:"+ex.getMessage());
		}finally{
			try {
				fis.close();
				book.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	
	public static List<BookSheet> getFromtoDate(String fromDate,String toDate,String sheetName){
		List<BookSheet>	list 	= null;
		FileInputStream fis		= null;
		
		XSSFWorkbook book		= null;
		XSSFSheet sheet			= null;
		BookSheet bookSheet		= null;
		try{
			fis	= new FileInputStream(new File("D:\\"+sheetName+".xlsx"));
			book= new XSSFWorkbook(fis);
			sheet = book.getSheetAt(0);
			list = new ArrayList<BookSheet>();
			Iterator<Row> rowItr = sheet.iterator();
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			ArrayList<String> datesList = new ArrayList<String>();
			 Date fromDate1 = sdf.parse(fromDate);
		        Date toDate1 = sdf.parse(toDate);

		        System.out.println("From " + fromDate1);
		        System.out.println("To " + toDate1);

		        Calendar cal = Calendar.getInstance();
		        cal.setTime(fromDate1);
		        cal.add(Calendar.DAY_OF_MONTH, -1);
		        while (cal.getTime().before(toDate1)) {
		            cal.add(Calendar.DATE, 1);
		            datesList.add(sdf.format(cal.getTime()));
		        }
		        System.out.println(datesList);
			while(rowItr.hasNext()){
				bookSheet 	= new BookSheet();
				//int cellIdx = 0;
				Row row 	= rowItr.next();
		        //Date start = sdf.parse(fromDate);
		        //Date end = sdf.parse(toDate);
		        //Date input = new Date();
		       // LocalDate start = input.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		       if(datesList!=null && datesList.size()>0){
		    	   Iterator<String> dateitr=datesList.iterator();  
			        while(dateitr.hasNext()){  
						if(getCellValue(row.getCell(1))!=null && getCellValue(row.getCell(1)).equalsIgnoreCase(dateitr.next().toString())){
							bookSheet.setSheetName(sheetName);
							if(row.getCell(0)!=null)
								bookSheet.setSno(getCellValue(row.getCell(0)));
							if(row.getCell(1)!=null)
								bookSheet.setName(getCellValue(row.getCell(1)));
							if(row.getCell(2)!=null)
								bookSheet.setInc(getCellValue(row.getCell(2)));
							
							list.add(bookSheet);
						}
						
			        }
		       }
			}
		}catch(Exception ex){
			System.out.println("Error:getAllValues:"+ex.getMessage());
		}finally{
			try {
				fis.close();
				book.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	public static String getCellValue(Cell cell){
		try{
			if(cell!=null){
				switch (cell.getCellType()) {
	            case HSSFCell.CELL_TYPE_STRING:
	                return cell.getStringCellValue();
	            case HSSFCell.CELL_TYPE_NUMERIC:
	            	
	                    if (DateUtil.isCellDateFormatted(cell)) {
	                    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	                    	return sdf.format(cell.getDateCellValue());
	                    	//return Double.(cell.getDateCellValue());
	                    } else {
	                    	return Double.toString(cell.getNumericCellValue());
	                    }
	            
	                //return Double.toString(cell.getNumericCellValue());
	            case HSSFCell.CELL_TYPE_BOOLEAN:
	                return Boolean.toString(cell.getBooleanCellValue());
	            case HSSFCell.CELL_TYPE_FORMULA:
	                cell.getCellFormula();
	            }
					
			}
		}catch(Exception ex){
			System.out.println("Error:"+ex.getMessage());
			ex.printStackTrace();
		}
		return null;
	}

}
