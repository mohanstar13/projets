var itrCount = 0;
var elementCount = 0;
// add new row
$(".addCF").click(function(){
	//var newRow = $("#row1").html();
	itrCount = itrCount+1;
	elementCount = elementCount+1;
	var newRow = 
		'<tr>'
		+'<td><input type="text" class="code" id="sno'+itrCount+'" name="sno" required></td>'
		+'<td>'
		+'<select class="code" id="name'+itrCount+'" name="name" required>'
		+'	<option value="Default">Choose</option>'
		+'	<option value="Mohan">Mohan</option>'
		+'	<option value="Mani">Mani</option>'
		+'	<option value="Soosai">Soosai</option>'
		+'	<option value="Robert">Robert</option>'
		+'	<option value="Sathish">Sathish</option>'
		+'	<option value="Manoj">Manoj</option>'
		+'	<option value="Nagu">Nagu</option>'
		+'</select>'
		+'</td>'
		+'<td><input type="text" class="code" id="inc'+itrCount+'" name="inc" required></td>'
		+'<td><input type="text" class="code" id="fdate'+itrCount+'" name="fdate" required></td>'
		+'<td><input type="text" class="code" id="tdate'+itrCount+'" name="tdate" onblur="diff('+itrCount+')" required></td>'
		+'<td><input type="text" class="code" id="remain'+itrCount+'" name="remain" required>&nbsp;<a href="javascript:void(0);" class="remCF">Rmv</a></td>'
		+'</tr>';
	$("#customFields").append(newRow);
});

// remove added row
$("#customFields").on('click','.remCF',function(){
	elementCount = elementCount - 1;
    $(this).parent().parent().remove();
});

// form submit action
$("#submitBtn").on('click',function(){
    var fromName = document.forms[0];
    if(validateForm()){
    	if((fromName.viewType.value=="json")){
    		$('#neDiv').html(insertNewRowAjax(fromName));
    		if($('#newTable')){
    			$('#newTable').DataTable();
    		}
    	}else{
    		formSubmit(fromName);
    	}
    }
});

function validateForm(){
	var frm = document.forms[0];
	if(frm.viewType.value == null || frm.viewType.value == ''){
		focusById(frm.viewType[0].id);
		showError("Choose View As Option");
		return false;
	}
	if(frm.sheetName.value == null || frm.sheetName.value == ''){
		focusById(frm.sheetName.id);
		showError("Choose Sheet Name");
		return false;
	}
	if(elementCount > 0){
		var arrySno = frm.sno;
		for(var i=0;i<arrySno.length;i++){
			console.log(arrySno[i]);
			if(arrySno[i].value == null || arrySno[i].value == ''){
				focusById(arrySno[i].id);
				showError("Fill S.No");
				return false;
			}
		}
		var arryNames = frm.name;
		for(var i=0;i<arryNames.length;i++){
			if(arryNames[i].value == null || arryNames[i].value == 'Default'){
				focusById(arryNames[i].id);
				showError("Choose Name");
				return false;			
			}
		}
		
		var arryIncs = frm.inc;
		for(var i=0;i<arryIncs.length;i++){
			if(arryIncs[i].value == null || arryIncs[i].value == ''){
				focusById(arryIncs[i].id);
				showError("Fill Inc");
				return false;			
			}
		}
		
	}else{
		if(frm.sno.value == null || frm.sno.value == '' || frm.sno.length == 0){
			focusById(frm.sno.id);
			showError("Fill S.No");
			return false;
		}
		if(frm.name.value == null || frm.name.value == 'Default' || frm.name.length == 0){
			focusById(frm.name.id);
			showError("Choose Name");
			return false;
		}
		if(frm.inc.value == null || frm.inc.value == '' || frm.inc.length == 0){
			focusById(frm.inc.id);
			showError("Fill inc");
			return false;
		}
	}
	
	return true;
}

function showError(msg){
	$('#errorText').text(msg).css("display","block").fadeOut(3000);
}
function focusById(id){
	if($('#'+id)){
		$('#'+id).focus();
	}
}
function toArray(data){
	var arry = new Array();
	if(typeof(data)!='undefined'&&data.length>0){
		for(var i=0;i<data.length;i++){
			arry.push(data[i].value);
		}
	}
	return arry;
}
// from submit ajax call
function insertNewRowAjax(formData){
	if(formData!=null && formData!=""){
		var sheetName = $("#sheetName").val();
		var snos 	= document.getElementsByName("sno");
		var names 	= document.getElementsByName("name");
		var incs 	= document.getElementsByName("inc");
		var viewType = formData.viewType.value;
		if(sheetName!=null && sheetName!='' && snos!=null && snos!='' && 
						names!=null && names!='' && incs!=null && incs!=''){
			snos = toArray(snos);
			names = toArray(names);
			incs = toArray(incs);
			//var fromData = new FormData();
			//return false;
		return	$.ajax({
				method : 'POST',
				async:false,
				timeout:5000,
				url: $('#form1').attr("action"),   
			    data: $('#form1').serialize(),
				success:function(res){
					console.log(res);
					//console.log(JSON.stringify(data));
				},
				error:function(jqXHR, textStatus, errorThrown){
					if(textStatus==="timeout") {
						showError("Ajax Timeout Error");
						console.log("Ajax Timeout Error");
				     } 
					console.log("jqXHR "+jqXHR);
					console.log("textStatus "+textStatus);
					console.log("errorThrown "+errorThrown);
					showError("Ajax Error");
				}
			}).responseText;
		} 
	}
}

//from normal submit html action
function formSubmit(form){
	form.submit();
}
function diff(index){
	if($('#fdate'+index) && $('#tdate'+index) &&
			$('#fdate'+index).val()!='' && $('#tdate'+index).val()!='' &&
				$('#fdate'+index).val()!='NaN' && $('#tdate'+index).val()!='NaN'){
		var date1 = new Date($('#fdate'+index).val());
		var date2 = new Date($('#tdate'+index).val());
		var timeDiff = Math.abs(date2.getTime() - date1.getTime());
		var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
		$('#remain'+index).val(diffDays);
		//alert(diffDays);
	}
}