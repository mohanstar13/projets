$(document).ready(function(){
	
	$('#eodDiv').css("display","block");
	$('.incDate').val(todayDate(0));
	$('#fromToDiv').css("display","none");
	$('#incDiv').css("display","none");
	$('#errTxt').css("display","none");
	
	$('#sendeod').click(function(){
		$('#eodDiv').css("display","block");
		$('.incDate').val(todayDate(0));
		$('#fromToDiv').css("display","none");
		$('#incDiv').css("display","none");
		$('#submitBtn').focus();
	});
	$('#searchdate').click(function(){
		$('#eodDiv').css("display","none");
		$('#fromToDiv').css("display","block");
		$('.fromDate').val(todayDate(-1)).focus();
		$('.toDate').val(todayDate(0));	
		$('#incDiv').css("display","none");
	});
	$('#searchinc').click(function(){
		$('#eodDiv').css("display","none");
		$('#fromToDiv').css("display","none");
		$('#incDiv').css("display","block");$('.incNo').focus();
	});
	$('#submitBtn').click(function(){
		var sel = $('input[name=dateMode]:checked').val();
		if(validateForm()){
			if(sel=='sendeod'){
				eod($('.incDate').val());
			}
			if(sel=='searchdate'){
				$('#resCntent').html(fromdatetodate($('.fromDate').val(),$('.toDate').val()));
				if($('#newAjaxTable')){
					$('#newAjaxTable').DataTable();
				}
			}
		}
	
	});
});

function ajaxCall(){
	
}

function eod(incDate){
	log(incDate);
	$.ajax({
		method : 'POST',
		async:false,
		timeout:5000,
		data : {incDate:incDate,dateMode:'sendeod',sheetName:$('#sheetName').val()},
		url : "SentEod",
		success:function(res){
			log(res);
			log(JSON.stringify(res));
			showError("Mail Sent Successfully.....");
		},
		error:function(jqXHR, textStatus, errorThrown){
			if(textStatus==="timeout") {
				showError("Ajax Timeout Error");
				log("Ajax Timeout Error");
		     } 
			showError("jqXHR "+jqXHR);
			showError("textStatus "+textStatus);
			showError("errorThrown "+errorThrown);
			showError("Ajax Error");
		}
	});
}
function log(msg){
	console.log(">>> "+msg);
}
function validateForm(){
	
	if($('#sheetName').val()=='def'){
		showError('Please select the sheet');
		$('#sheetName').focus();
		return false;
	}
	
	var sel = $('input[name=dateMode]:checked').val();
	
	if(sel=='searchdate'){
		if($('.fromDate').val()==$('.toDate').val()){
			showError('From and To date Cant be same.');
			$('.toDate').focus();
			return false;
		}
	}
	
	if(sel=='searchinc'){
		if($('.incNo').val()=='' || $('.incNo').val()==null){
			showError('Please Enter the Inc No');
			$('.incNo').focus();
			return false;
		}
	}
	
	return true;
}

function showError(msg) {
	$('#errTxt').html(msg).css("display","block").fadeOut(4000);
}
function todayDate(cdate) {
	var CurrentDate = new Date();
	CurrentDate.setMonth(CurrentDate.getMonth());
	var day = CurrentDate.getDate()+cdate;
	var month = CurrentDate.getMonth()+1;
	var year = CurrentDate.getFullYear();
	if (month < 10)
		month = "0" + month;
	if (day < 10)
		day = "0" + day;
	var today = year + "-" + month + "-" + day;	
	return today;
}
function fromdatetodate(fromDate,toDate){
	log(fromDate);
 return	$.ajax({
		method : 'POST',
		async:false,
		timeout:5000,
		data : {fromDate:fromDate,toDate:toDate,dateMode:'searchdate',sheetName:$('#sheetName').val()},
		url : "SentEod",
		success:function(res){
			log(res);
			showError("Mail Sent Successfully.....");
		},
		error:function(jqXHR, textStatus, errorThrown){
			if(textStatus==="timeout") {
				showError("Ajax Timeout Error");
				log("Ajax Timeout Error");
		     } 
			//showError("jqXHR "+jqXHR);
			//showError("textStatus "+textStatus);
			//showError("errorThrown "+errorThrown);
			//showError("Ajax Error");
		}
	}).responseText;
}
