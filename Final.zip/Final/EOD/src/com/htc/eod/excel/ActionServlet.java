package com.htc.eod.excel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class check
 */
@WebServlet("/ActionServlet")
public class ActionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean isInsert=false;
		try{
			if(request.getParameterValues("inc[]")!=null){
				String[] inc=request.getParameterValues("inc[]");
				String name=request.getParameter("name");
				String date=request.getParameter("date");
				String[] defect=request.getParameterValues("defect[]");
				String[] dtitle=request.getParameterValues("dtitle[]");
				String[] istatus=request.getParameterValues("istatus[]");
				String[] kid=request.getParameterValues("kid[]");
				String[] ebe=request.getParameterValues("ebe[]");
				String[] otime=request.getParameterValues("otime[]");
				String[] ctime=request.getParameterValues("ctime[]");
				String[] htime=request.getParameterValues("htime[]");
				String[] pri=request.getParameterValues("pri[]");
				String[] delay=request.getParameterValues("delay[]");
				String[] dc=request.getParameterValues("dc[]");
				String shift=request.getParameter("shift");
				
				
				List<ExcelData> list=null;
				ExcelData sheet=null;
				if(inc.length>0){
					list=new ArrayList<ExcelData>();
					{
						for(int i=0;i<inc.length;i++){
							sheet =new ExcelData();
							sheet.setInc((String)inc[i]);
							sheet.setName((String)name);
							sheet.setDate((String)date);
							sheet.setDefect((String)defect[i]);
							sheet.setDtitle((String)dtitle[i]);
							sheet.setIstatus((String)istatus[i]);
							sheet.setKid((String)kid[i]);
							sheet.setEbe((String)ebe[i]);
							sheet.setOtime((String)otime[i]);
							sheet.setCtime((String)ctime[i]);
							sheet.setHtime((String)htime[i]);
							sheet.setPri((String)pri[i]);
							sheet.setDelay((String)delay[i]);
							sheet.setShift((String)shift);
							
							list.add(sheet);
						}
						ExcelBook book=new ExcelBook();
						if(list!=null&&list.size()>0){
							isInsert=book.insertNewRow(list,name)?true:false;
						}
					}
				}
			}
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		System.out.println(isInsert);
		doGet(request, response);
	}

}
