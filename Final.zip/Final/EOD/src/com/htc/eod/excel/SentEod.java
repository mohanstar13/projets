package com.htc.eod.excel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SentEod
 */
@WebServlet("/SentEod")
public class SentEod extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SentEod() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		request.setCharacterEncoding("utf8");
		PrintWriter pw = response.getWriter();
		response.setContentType("application/json");
		
		String dateMode = request.getParameter("dateMode");
		String sheetName = request.getParameter("sheetName");
		try{
			if(("sendeod").equalsIgnoreCase(dateMode)){
				String incDate = request.getParameter("incDate");
				
				String resText = "";
				if(incDate!=null){
					Mail mail = new Mail();
					resText = mail.sendMail("TEST MAIL"+incDate+" sheetName"+sheetName,sheetName);
					pw.println("RES:"+resText);
				}
			}
			if(("searchdate").equalsIgnoreCase(dateMode)){
				String fromDate = request.getParameter("fromDate");
				String toDate = request.getParameter("toDate");
				String resText = "";
				if(fromDate!=null && toDate!=null ){
					Viewdates date = new Viewdates();
					resText = date.dateSearch(fromDate,toDate,sheetName);
					
					pw.println(resText);
				}
			}
			if(("searchinc").equalsIgnoreCase(dateMode)){
				String inc = request.getParameter("incident");		
				String resText = "";
				if(inc!=null){
					Viewdates date = new Viewdates();
					resText = date.incsearch(inc,sheetName);
					
					pw.println(resText);
				}
			}
		}catch(Exception ex){
			System.out.println(ex.getMessage());
			pw.println("RES:"+"EXECEPTION");
			ex.printStackTrace();
		}
			
	}

}
