package com.htc.eod.excel;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;


public class ExcelBook {
	public boolean insertNewRow(List<ExcelData> list,String name){
		boolean inserted=false;
		XSSFWorkbook workbook=new XSSFWorkbook();;
		XSSFSheet sheet=null;
		ExcelData exceldata=null;
		FileOutputStream out=null;
		try{
			
			InputStream myxls=null;
			 FileOutputStream fos = null;
			
	       // InputStream myxls = new FileInputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+name+".xlsx"));
	        
	        File f = new File("C:\\Users\\eurd\\Desktop\\EOD\\"+name+".xlsx");
	        if(f.exists()) { 
	        	 myxls = new FileInputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+name+".xlsx"));
	        }
	        else
	        {
        	
	     		try {
	     			workbook.createSheet("Sheet1"); 
	     			fos=new FileOutputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+name+".xlsx"));	 	     			
	     			workbook.write(fos);	     			
	     			fos.close();
	     			 myxls = new FileInputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+name+".xlsx"));
	     		} catch (Exception e) {
	     			e.printStackTrace();
	     		}
	        }
	       
			workbook =new XSSFWorkbook(myxls);
			sheet=workbook.getSheet("Sheet1");
			int rownum=sheet.getLastRowNum()+1;
			Iterator<ExcelData> itr=list.iterator();
			while(itr.hasNext()){
				int cellIdx=0;
				exceldata=itr.next();
				Row row=sheet.createRow(rownum++);
				row.createCell(cellIdx++).setCellValue(rownum-1);
				row.createCell(cellIdx++).setCellValue((String)exceldata.getDate());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getName());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getDefect());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getInc());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getDtitle());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getIstatus());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getKid());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getEbe());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getOtime());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getCtime());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getHtime());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getPri());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getDelay());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getDc());
				row.createCell(cellIdx++).setCellValue((String)exceldata.getShift());
				
			}
			out=new FileOutputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+name+".xlsx"));
			workbook.write(out);
			out.close();
	
			inserted=true;
			
		}catch(Exception ex){
			inserted=false;
			System.out.println("Error"+ex.getMessage());
			ex.printStackTrace();
		}
		return inserted;
	}
	public static List<ExcelData> getAllRowValues(String name){
		List<ExcelData> list=null;
		FileInputStream fis=null;
		XSSFWorkbook book=null;
		XSSFSheet sheet=null;
		ExcelData data=null;
		try{
			fis=new FileInputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+name+".xlsx"));
			book=new XSSFWorkbook(fis);
			sheet=book.getSheet("Sheet1");
			list =new ArrayList<ExcelData>();
			Iterator<Row> rowItr =sheet.iterator();
			while(rowItr.hasNext()){
			            data=new ExcelData();
			            int cellIdx=0;
			            Row row=rowItr.next();
			            if(row.getCell(0)!=null)
			            data.setSL_No(getCellValue(row.getCell(0)));
			            data.setDate(getCellValue(row.getCell(1)));
			            data.setName(getCellValue(row.getCell(2)));
			            data.setDefect(getCellValue(row.getCell(3)));
			            data.setInc(getCellValue(row.getCell(4)));
			            data.setDtitle(getCellValue(row.getCell(5)));
			            data.setIstatus(getCellValue(row.getCell(6)));
			            data.setKid(getCellValue(row.getCell(7)));
			            data.setEbe(getCellValue(row.getCell(8)));
			            data.setOtime(getCellValue(row.getCell(9)));			           
			            data.setCtime(getCellValue(row.getCell(10)));
			            data.setHtime(getCellValue(row.getCell(11)));
			            data.setPri(getCellValue(row.getCell(12)));
			            data.setDelay(getCellValue(row.getCell(13)));
			            data.setDc(getCellValue(row.getCell(14)));
			            data.setShift(getCellValue(row.getCell(15)));			            
			            list.add(data);
			 
			}
			
			
		}catch(Exception ex){
			System.out.println("Error:"+ex.getMessage());
		}finally{
			try{
				fis.close();
				//book.close();
			}catch(IOException e){
				e.printStackTrace();
			}
		}
		return list;
		
	}
	public static List<ExcelData> getAllRowValuesFromTo(String name,String From,String To){
		List<ExcelData> list=null;
		FileInputStream fis=null;
		XSSFWorkbook book=null;
		XSSFSheet sheet=null;
		ExcelData data=null;
		try{
			fis=new FileInputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+name+".xlsx"));
			book=new XSSFWorkbook(fis);
			sheet=book.getSheet("Sheet1");
			list =new ArrayList<ExcelData>();
			Iterator<Row> rowItr =sheet.iterator();
			while(rowItr.hasNext()){
			            data=new ExcelData();
			            int cellIdx=0;
			            Row row=rowItr.next();
			            if(row.getCell(0)!=null)
			            	getCellValue(row.getCell(1));
			            data.setSL_No(getCellValue(row.getCell(0)));
			            data.setDate(getCellValue(row.getCell(1)));
			            data.setName(getCellValue(row.getCell(2)));
			            data.setDefect(getCellValue(row.getCell(3)));
			            data.setInc(getCellValue(row.getCell(4)));
			            data.setDtitle(getCellValue(row.getCell(5)));
			            data.setIstatus(getCellValue(row.getCell(6)));
			            data.setKid(getCellValue(row.getCell(7)));
			            data.setEbe(getCellValue(row.getCell(8)));
			            data.setOtime(getCellValue(row.getCell(9)));			           
			            data.setCtime(getCellValue(row.getCell(10)));
			            data.setHtime(getCellValue(row.getCell(11)));
			            data.setPri(getCellValue(row.getCell(12)));
			            data.setDelay(getCellValue(row.getCell(13)));
			            data.setDc(getCellValue(row.getCell(14)));
			            data.setShift(getCellValue(row.getCell(15)));			            
			            list.add(data);
			 
			}
			
			
		}catch(Exception ex){
			System.out.println("Error:"+ex.getMessage());
		}finally{
			try{
				fis.close();
				//book.close();
			}catch(IOException e){
				e.printStackTrace();
			}
		}
		return list;
		
	}
	public static StringBuffer getSheetValueAsHtml(List<ExcelData> list,String name){
		StringBuffer strBuf =new StringBuffer();
		ExcelData data=null;
		try{
			if(list !=null && list.size()>0){
				Iterator<ExcelData> itr=list.iterator();
				strBuf.append("<table border='1'>");
				while(itr.hasNext()){
					data=itr.next();
					if(data !=null){
						strBuf.append("<tr>");
						strBuf.append("<td>"+data.getSL_No()+"</td>");
						strBuf.append("<td>"+data.getDate()+"</td>");
						strBuf.append("<td>"+data.getName()+"</td>");
						strBuf.append("<td>"+data.getDefect()+"</td>");
						strBuf.append("<td>"+data.getInc()+"</td>");
						strBuf.append("<td>"+data.getDtitle()+"</td>");
						strBuf.append("<td>"+data.getDtitle()+"</td>");
						strBuf.append("<td>"+data.getIstatus()+"</td>");
						strBuf.append("<td>"+data.getKid()+"</td>");
						strBuf.append("<td>"+data.getEbe()+"</td>");
						strBuf.append("<td>"+data.getOtime()+"</td>");
						strBuf.append("<td>"+data.getCtime()+"</td>");
						strBuf.append("<td>"+data.getHtime()+"</td>");
						strBuf.append("<td>"+data.getPri()+"</td>");
						strBuf.append("<td>"+data.getDelay()+"</td>");
						strBuf.append("<td>"+data.getDc()+"</td>");
						strBuf.append("<td>"+data.getShift()+"</td>");
						
						strBuf.append("</tr>");
						
					}
				}
				strBuf.append("</table>");
				
			}
		}catch(Exception ex){
			System.out.println("Error"+ex.getMessage());
			ex.printStackTrace();
		}
		return strBuf;
	}
	public static String getCellValue(Cell cell){
		try{
			if(cell!=null){
				switch(cell.getCellType()){
				case HSSFCell.CELL_TYPE_STRING:
					return cell.getStringCellValue();
				case HSSFCell.CELL_TYPE_NUMERIC:
					return Double.toString(cell.getNumericCellValue());
				case HSSFCell.CELL_TYPE_BOOLEAN:
					return Boolean.toString(cell.getBooleanCellValue());
				case HSSFCell.CELL_TYPE_FORMULA:
					cell.getCellFormula();
				}
			}
		}catch(Exception ex){
			System.out.println("Error:"+ex.getMessage());
			ex.printStackTrace();
		}
		return null;
	}
	public static boolean isValidSheet(String sheetName){
		boolean flag = false;
		try{
			File file 	= new File("C:\\Users\\eurd\\Desktop\\EOD\\"+sheetName+".xlsx");
			flag 		= file.isFile(); 
		}catch(Exception ex){
			System.out.println("Error:"+ex.getMessage());
			ex.printStackTrace();
		}
		return flag;
	}
	
	public static String getValuesAsJson(List<ExcelData> list){
		String json = "'object':'null'";
		try{
			ObjectMapper mapper = new ObjectMapper();
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			json = mapper.writeValueAsString(list); 
		}catch(Exception ex){
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		return json;
	}

}
