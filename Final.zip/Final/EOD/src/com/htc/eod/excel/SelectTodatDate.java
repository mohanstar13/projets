package com.htc.eod.excel;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SelectTodatDate {
	public static List<ExcelData> getAllRowValues(String sheetName,String date){
		List<ExcelData>	list 	= null;
		FileInputStream fis		= null;
		XSSFWorkbook book		= null;
		XSSFSheet sheet			= null;
		ExcelData data		= null;
		try{
			fis	= new FileInputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+sheetName+".xlsx"));
			book= new XSSFWorkbook(fis);
			sheet = book.getSheetAt(0);
			list = new ArrayList<ExcelData>();
			Iterator<Row> rowItr = sheet.iterator();
			while(rowItr.hasNext()){
				data 	= new ExcelData();
				int cellIdx = 0;
				Row row 	= rowItr.next();
				//data.setSheetName(sheetName);
				 SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			        Date date1 = sdf.parse("2017/01/08");
			        Date date2 = sdf.parse(getCellValue(row.getCell(1)));
				System.out.println(date1);
				System.out.println(date2);
				
				if(date1.compareTo(date2) == 0){
					getCellValue(row.getCell(1));
		            data.setSL_No(getCellValue(row.getCell(0)));
		            data.setDate(getCellValue(row.getCell(1)));
		            data.setName(getCellValue(row.getCell(2)));
		            data.setDefect(getCellValue(row.getCell(3)));
		            data.setInc(getCellValue(row.getCell(4)));
		            data.setDtitle(getCellValue(row.getCell(5)));
		            data.setIstatus(getCellValue(row.getCell(6)));
		            data.setKid(getCellValue(row.getCell(7)));
		            data.setEbe(getCellValue(row.getCell(8)));
		            data.setOtime(getCellValue(row.getCell(9)));			           
		            data.setCtime(getCellValue(row.getCell(10)));
		            data.setHtime(getCellValue(row.getCell(11)));
		            data.setPri(getCellValue(row.getCell(12)));
		            data.setDelay(getCellValue(row.getCell(13)));
		            data.setDc(getCellValue(row.getCell(14)));
		            data.setShift(getCellValue(row.getCell(15)));			            
		            list.add(data);
				}
				
			}
		}catch(Exception ex){
			System.out.println("Error:getAllValues:"+ex.getMessage());
		}finally{
			try {
				fis.close();
				//book.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	
	public static List<ExcelData> getFromtoDate(String fromDate,String toDate,String sheetName){
		List<ExcelData>	list 	= null;
		FileInputStream fis		= null;
		
		XSSFWorkbook book		= null;
		XSSFSheet sheet			= null;
		ExcelData data		= null;
		try{
			fis	= new FileInputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+sheetName+".xlsx"));
			book= new XSSFWorkbook(fis);
			sheet = book.getSheetAt(0);
			list = new ArrayList<ExcelData>();
			Iterator<Row> rowItr = sheet.iterator();
			
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			ArrayList<String> datesList = new ArrayList<String>();
			    Date fromDate1 = sdf.parse(fromDate);
		        Date toDate1 = sdf.parse(toDate);
		        Calendar cal = Calendar.getInstance();
		        cal.setTime(fromDate1);
		        cal.add(Calendar.DAY_OF_MONTH, -1);
		        while (cal.getTime().before(toDate1)) {
		            cal.add(Calendar.DATE, 1);
		            datesList.add(sdf.format(cal.getTime()));
		        }

			while(rowItr.hasNext()){
				data 	= new ExcelData();				
				Row row 	= rowItr.next();
		       if(datesList!=null && datesList.size()>0){
		    	   Iterator<String> dateitr=datesList.iterator();  
			        while(dateitr.hasNext()){  
			        	
						if((row.getCell(1))!=null && getCellValue(row.getCell(1)).equalsIgnoreCase(dateitr.next().toString())){
				            data.setSL_No(getCellValue(row.getCell(0)));
				            data.setDate(getCellValue(row.getCell(1)));
				            data.setName(getCellValue(row.getCell(2)));
				            data.setDefect(getCellValue(row.getCell(3)));
				            data.setInc(getCellValue(row.getCell(4)));
				            data.setDtitle(getCellValue(row.getCell(5)));
				            data.setIstatus(getCellValue(row.getCell(6)));
				            data.setKid(getCellValue(row.getCell(7)));
				            data.setEbe(getCellValue(row.getCell(8)));
				            data.setOtime(getCellValue(row.getCell(9)));			           
				            data.setCtime(getCellValue(row.getCell(10)));
				            data.setHtime(getCellValue(row.getCell(11)));
				            data.setPri(getCellValue(row.getCell(12)));
				            data.setDelay(getCellValue(row.getCell(13)));
				            data.setDc(getCellValue(row.getCell(14)));
				            data.setShift(getCellValue(row.getCell(15)));			            
				            list.add(data);
						}
						
			        }
		       }
		      
			}
		}catch(Exception ex){
			System.out.println("Error:getAllValues:"+ex.getMessage());
		}finally{
			try {
				fis.close();
				//book.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	public static List<ExcelData> getIncident(String inc,String sheetName){
		List<ExcelData>	list 	= null;
		FileInputStream fis		= null;
		
		XSSFWorkbook book		= null;
		XSSFSheet sheet			= null;
		ExcelData data		= null;
		try{
			fis	= new FileInputStream(new File("C:\\Users\\eurd\\Desktop\\EOD\\"+sheetName+".xlsx"));
			book= new XSSFWorkbook(fis);
			sheet = book.getSheetAt(0);
			list = new ArrayList<ExcelData>();
			Iterator<Row> rowItr = sheet.iterator();
			while(rowItr.hasNext()){
				data 	= new ExcelData();				
				Row row 	= rowItr.next();		  	        	
						if(getCellValue(row.getCell(4)).equalsIgnoreCase(inc)){
				            data.setSL_No(getCellValue(row.getCell(0)));
				            data.setDate(getCellValue(row.getCell(1)));
				            data.setName(getCellValue(row.getCell(2)));
				            data.setDefect(getCellValue(row.getCell(3)));
				            data.setInc(getCellValue(row.getCell(4)));
				            data.setDtitle(getCellValue(row.getCell(5)));
				            data.setIstatus(getCellValue(row.getCell(6)));
				            data.setKid(getCellValue(row.getCell(7)));
				            data.setEbe(getCellValue(row.getCell(8)));
				            data.setOtime(getCellValue(row.getCell(9)));			           
				            data.setCtime(getCellValue(row.getCell(10)));
				            data.setHtime(getCellValue(row.getCell(11)));
				            data.setPri(getCellValue(row.getCell(12)));
				            data.setDelay(getCellValue(row.getCell(13)));
				            data.setDc(getCellValue(row.getCell(14)));
				            data.setShift(getCellValue(row.getCell(15)));			            
				            list.add(data);
						}
						
			       
		      
		      
			}
		}catch(Exception ex){
			System.out.println("Error:getAllValues:"+ex.getMessage());
		}finally{
			try {
				fis.close();
				//book.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	public static String getCellValue(Cell cell){
		try{
			if(cell!=null){
				switch (cell.getCellType()) {
	            case HSSFCell.CELL_TYPE_STRING:
	                return cell.getStringCellValue();
	            case HSSFCell.CELL_TYPE_NUMERIC:
	            	
	                    if (DateUtil.isCellDateFormatted(cell)) {
	                    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	                    	return sdf.format(cell.getDateCellValue());
	                    	//return Double.(cell.getDateCellValue());
	                    } else {
	                    	return Double.toString(cell.getNumericCellValue());
	                    }
	            
	                //return Double.toString(cell.getNumericCellValue());
	            case HSSFCell.CELL_TYPE_BOOLEAN:
	                return Boolean.toString(cell.getBooleanCellValue());
	            case HSSFCell.CELL_TYPE_FORMULA:
	                cell.getCellFormula();
	            }
					
			}
		}catch(Exception ex){
			System.out.println("Error:"+ex.getMessage());
			ex.printStackTrace();
		}
		return null;
	}

}
