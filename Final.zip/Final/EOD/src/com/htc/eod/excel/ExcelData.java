package com.htc.eod.excel;

import java.io.Serializable;

public class ExcelData implements Serializable {
	private String SL_No;
	private String date;
	private String name;
	private String defect;
	private String inc;
	private String dtitle;
	private String istatus;
	private String kid;
	private String ebe;
	private String otime;
	private String ctime;
	private String htime;
	public String getHtime() {
		return htime;
	}
	public void setHtime(String htime) {
		this.htime = htime;
	}
	private String pri;
	private String delay;
	private String dc;
	private String shift;
	public String getSL_No() {
		return SL_No;
	}
	public void setSL_No(String sL_No) {
		SL_No = sL_No;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDefect() {
		return defect;
	}
	public void setDefect(String defect) {
		this.defect = defect;
	}
	public String getInc() {
		return inc;
	}
	public void setInc(String inc) {
		this.inc = inc;
	}
	public String getDtitle() {
		return dtitle;
	}
	public void setDtitle(String dtitle) {
		this.dtitle = dtitle;
	}
	public String getIstatus() {
		return istatus;
	}
	public void setIstatus(String istatus) {
		this.istatus = istatus;
	}
	public String getKid() {
		return kid;
	}
	public void setKid(String kid) {
		this.kid = kid;
	}
	public String getEbe() {
		return ebe;
	}
	public void setEbe(String ebe) {
		this.ebe = ebe;
	}
	public String getOtime() {
		return otime;
	}
	public void setOtime(String otime) {
		this.otime = otime;
	}
	public String getCtime() {
		return ctime;
	}
	public void setCtime(String ctime) {
		this.ctime = ctime;
	}
	public String getPri() {
		return pri;
	}
	public void setPri(String pri) {
		this.pri = pri;
	}
	public String getDelay() {
		return delay;
	}
	public void setDelay(String delay) {
		this.delay = delay;
	}
	public String getDc() {
		return dc;
	}
	public void setDc(String dc) {
		this.dc = dc;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	

}
