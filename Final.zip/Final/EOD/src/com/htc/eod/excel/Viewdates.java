package com.htc.eod.excel;
import java.util.Iterator;
import java.util.List;

public class Viewdates {
	
	public String dateSearch(String fromDate,String toDate,String sheetName){
		try{
		 StringBuffer strBuf	= new StringBuffer();
	      List<ExcelData> datas= SelectTodatDate.getFromtoDate(fromDate,toDate,sheetName);
	      ExcelData data		= null;
	      Iterator<ExcelData> itr = datas.iterator();
	    
			strBuf.append("<table id='newAjaxTable'>"
					+ "<thead><tr><td>S.no</td>"
					+ "<td>Date</td><td>Name</td>"
					+ "<td>Defect</td><td>Incident</td>"
					+ "<td>Defect Title</td><td>Incident status</td>"
					+ "<td>KI ID</td><td>Error before error</td>"
					+ "<td>Open Time</td><td>Reassignment/Closure Time</td>"
					+ "<td>Handle Time</td><td>Priority</td><td>Reason for delay</td>"
					+ "<td>Which DC</td><td>Shift</td>"
					+ "</tr></thead>");
			strBuf.append("<tbody>");
			while(itr.hasNext()){
				data = itr.next();
				if(data!=null){
					strBuf.append("<tr>");
					strBuf.append("<td>"+data.getSL_No()+"</td>");
					strBuf.append("<td>"+data.getDate()+"</td>");
					strBuf.append("<td>"+data.getName()+"</td>");
					strBuf.append("<td>"+data.getDefect()+"</td>");
					strBuf.append("<td>"+data.getInc()+"</td>");
					strBuf.append("<td>"+data.getDtitle()+"</td>");			
					strBuf.append("<td>"+data.getIstatus()+"</td>");
					strBuf.append("<td>"+data.getKid()+"</td>");
					strBuf.append("<td>"+data.getEbe()+"</td>");
					strBuf.append("<td>"+data.getOtime()+"</td>");
					strBuf.append("<td>"+data.getCtime()+"</td>");
					strBuf.append("<td>"+data.getHtime()+"</td>");
					strBuf.append("<td>"+data.getPri()+"</td>");
					strBuf.append("<td>"+data.getDelay()+"</td>");
					strBuf.append("<td>"+data.getDc()+"</td>");
					strBuf.append("<td>"+data.getShift()+"</td>");
					
					strBuf.append("</tr>");
				}
			}
			strBuf.append("</tbody>");
			strBuf.append("<tfoot></tfoot>");
			strBuf.append("</table><br>");
			System.out.println(strBuf.toString());
			return strBuf.toString();
		}
		catch (Exception ex){
	    	ex.printStackTrace();
	       System.out.println(ex.getMessage());
	       return "failure";
	    }
		
	}
	public String incsearch(String inc,String sheetName){
		try{
		 StringBuffer strBuf	= new StringBuffer();
	      List<ExcelData> datas= SelectTodatDate.getIncident(inc,sheetName);
	      ExcelData data		= null;
	      Iterator<ExcelData> itr = datas.iterator();
	    
			strBuf.append("<table id='newAjaxTable'>"
					+ "<thead><tr><td>S.no</td>"
					+ "<td>Date</td><td>Name</td>"
					+ "<td>Defect</td><td>Incident</td>"
					+ "<td>Defect Title</td><td>Incident status</td>"
					+ "<td>KI ID</td><td>Error before error</td>"
					+ "<td>Open Time</td><td>Reassignment/Closure Time</td>"
					+ "<td>Handle Time</td><td>Priority</td><td>Reason for delay</td>"
					+ "<td>Which DC</td><td>Shift</td>"
					+ "</tr></thead>");
			strBuf.append("<tbody>");
			while(itr.hasNext()){
				data = itr.next();
				if(data!=null){
					strBuf.append("<tr>");
					strBuf.append("<td>"+data.getSL_No()+"</td>");
					strBuf.append("<td>"+data.getDate()+"</td>");
					strBuf.append("<td>"+data.getName()+"</td>");
					strBuf.append("<td>"+data.getDefect()+"</td>");
					strBuf.append("<td>"+data.getInc()+"</td>");
					strBuf.append("<td>"+data.getDtitle()+"</td>");			
					strBuf.append("<td>"+data.getIstatus()+"</td>");
					strBuf.append("<td>"+data.getKid()+"</td>");
					strBuf.append("<td>"+data.getEbe()+"</td>");
					strBuf.append("<td>"+data.getOtime()+"</td>");
					strBuf.append("<td>"+data.getCtime()+"</td>");
					strBuf.append("<td>"+data.getHtime()+"</td>");
					strBuf.append("<td>"+data.getPri()+"</td>");
					strBuf.append("<td>"+data.getDelay()+"</td>");
					strBuf.append("<td>"+data.getDc()+"</td>");
					strBuf.append("<td>"+data.getShift()+"</td>");
					
					strBuf.append("</tr>");
				}
			}
			strBuf.append("</tbody>");
			strBuf.append("<tfoot></tfoot>");
			strBuf.append("</table><br>");
			System.out.println(strBuf.toString());
			return strBuf.toString();
		}
		catch (Exception ex){
	    	ex.printStackTrace();
	       System.out.println(ex.getMessage());
	       return "failure";
	    }
		
	}
	

}
