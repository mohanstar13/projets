package com.htc.eod.excel;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewServlet
 */
@WebServlet("/ViewSheet")
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		boolean validAction = true;
		if(request.getParameter("sheet")!=null){
			List<BookSheet> list =null;
			PrintWriter pw		= null;
			String sheetName	= null;
			String viewName		= null;
			try{
				sheetName = request.getParameter("sheet");
				viewName = request.getParameter("viewType");
				if(("html").equalsIgnoreCase(viewName)){
					pw = response.getWriter();
					response.setContentType("text/html");
					if(ExcelBook.isValidSheet(sheetName)){
						list = ExcelBook.getAllRowValues(sheetName);
						if(list!=null && list.size()>0){
							pw.println((ExcelBook.getSheetValueAsHtml(list)!=null)?ExcelBook.getSheetValueAsHtml(list).toString():"<b>Empty Values</b>");
						}
					}else{
						validAction = false;
					}
				}else{
					request.setCharacterEncoding("utf8");
					pw = response.getWriter();
					response.setContentType("application/json");
					if(ExcelBook.isValidSheet(sheetName)){
						list = ExcelBook.getAllRowValues(sheetName);
						if(list!=null && list.size()>0){
							pw.println((ExcelBook.getSheetValueAsHtml(list)));
						}
					}else{
						validAction = false;
					}
				}
			}
			catch(Exception ex){
				System.out.println("Error"+ex.getMessage());
				ex.printStackTrace();
			}
			
		}else{
			validAction = false;
		}
		if(!validAction){
			response.getWriter().append("Server Got Some ERROR ").append(request.getContextPath());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
